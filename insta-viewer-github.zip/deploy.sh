#!/bin/bash

echo "🚀 Instagram Story Viewer - Frontend Deployment"
echo "=============================================="

# Check if we're in the right directory
if [ ! -d "frontend" ]; then
    echo "❌ Error: frontend directory not found"
    echo "Please run this script from the project root directory"
    exit 1
fi

echo "✅ Frontend directory found"

# Navigate to frontend directory
cd frontend

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found in frontend directory"
    exit 1
fi

echo "✅ package.json found"

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ Error: Failed to install dependencies"
        exit 1
    fi
    echo "✅ Dependencies installed"
else
    echo "✅ Dependencies already installed"
fi

# Build the project
echo "🔨 Building project for production..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Error: Build failed"
    exit 1
fi

echo "✅ Build completed successfully!"
echo ""
echo "📁 Your build files are ready in: frontend/build/"
echo ""
echo "🚀 Deployment Options:"
echo ""
echo "1. 📤 Netlify Drop:"
echo "   - Go to https://netlify.com"
echo "   - Drag & drop the 'build' folder"
echo "   - Get instant free hosting!"
echo ""
echo "2. ⚡ Vercel CLI:"
echo "   npm install -g vercel"
echo "   vercel --prod"
echo ""
echo "3. 🌊 Surge.sh:"
echo "   npm install -g surge"
echo "   cd build && surge"
echo ""
echo "🎉 Your Instagram Story Viewer is ready to deploy!"
echo "No backend needed - it's a pure frontend redirect app!" 